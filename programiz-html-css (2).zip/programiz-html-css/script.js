// ---------- Insert bouncing name letters ----------
(function fillName() {
  const nameEl = document.querySelector('.name');
  const defaultName = nameEl.getAttribute('data-name') || 'Friend';
  const letters = Array.from(defaultName);
  nameEl.innerHTML = '';
  letters.forEach((ch, i) => {
    const span = document.createElement('span');
    span.textContent = ch === ' ' ? '\u00A0' : ch;
    span.style.animationDelay = (i * 0.08) + 's';
    nameEl.appendChild(span);
  });
})();

// ---------- Confetti Animation ----------
(function confettiModule() {
  const canvas = document.getElementById('confetti');
  const ctx = canvas.getContext('2d');
  let particles = [];
  let w = canvas.width = canvas.offsetWidth;
  let h = canvas.height = canvas.offsetHeight;
  let running = false;

  function resize() {
    w = canvas.width = canvas.offsetWidth;
    h = canvas.height = canvas.offsetHeight;
  }
  window.addEventListener('resize', resize);

  function rand(min, max) { return Math.random() * (max - min) + min; }
  const colors = ['#FF5FB7', '#FFD37A', '#A57BFF', '#7BE0FF', '#FF8DA1'];

  function makeParticle(x, y) {
    return {
      x, y,
      vx: rand(-6, 6), vy: rand(-12, -4),
      size: rand(6, 12),
      angle: rand(0, Math.PI * 2),
      spin: rand(-0.2, 0.4),
      color: colors[Math.floor(rand(0, colors.length))],
      life: rand(60, 120)
    };
  }

  function spawnBurst(cx, cy, amount = 40) {
    for (let i = 0; i < amount; i++) particles.push(makeParticle(cx + rand(-20, 20), cy + rand(-10, 10)));
    if (!running) { running = true; requestAnimationFrame(loop); }
  }

  function update() {
    for (let i = particles.length - 1;
